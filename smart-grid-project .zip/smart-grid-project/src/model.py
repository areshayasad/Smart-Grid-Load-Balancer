"""LSTM demand forecaster. Small on purpose -- keeps training fast on a CPU
laptop and keeps the checkpoint file tiny (space-friendly)."""
import torch
import torch.nn as nn


class DemandLSTM(nn.Module):
    def __init__(self, n_features, hidden_size=32, num_layers=1):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
        )
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, seq_len, n_features)
        out, _ = self.lstm(x)
        last_step = out[:, -1, :]
        return self.head(last_step).squeeze(-1)


if __name__ == "__main__":
    m = DemandLSTM(n_features=5)
    dummy = torch.randn(2, 24, 5)
    print(m(dummy).shape)  # -> torch.Size([2])
