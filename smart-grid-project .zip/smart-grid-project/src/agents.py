"""
The Act layer. Three concrete, checkable actions:
  1. Rebalancing agent  -> writes a row to the recommendations table
  2. Escalation agent   -> sends a real email via SMTP when no feeder has spare capacity
  3. Approval / execute -> logs the human's approval + a mock "executed" action
"""
import os
import smtplib
from email.mime.text import MIMEText

from dotenv import load_dotenv
import db

load_dotenv()

SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")          # your gmail address
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")  # gmail "app password", not your real password
ENGINEER_EMAIL = os.getenv("ENGINEER_EMAIL", SMTP_USER)


def send_escalation_email(feeder_id, predicted_mw, capacity_mw, confidence_mw):
    if not SMTP_USER or not SMTP_PASSWORD:
        print("[agents] SMTP not configured (.env missing) -- skipping real email, "
              "logging escalation instead.")
        return False, "SMTP not configured"

    subject = f"[Grid alert] {feeder_id} predicted to exceed capacity"
    body = (
        f"Feeder: {feeder_id}\n"
        f"Predicted demand: {predicted_mw:.1f} MW (+/- {confidence_mw:.1f} MW)\n"
        f"Capacity: {capacity_mw:.1f} MW\n\n"
        f"No neighboring feeder has enough spare capacity to absorb the overflow. "
        f"Manual intervention is needed.\n\n"
        f"-- Smart grid load balancer (automated)"
    )
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = SMTP_USER
    msg["To"] = ENGINEER_EMAIL

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_USER, [ENGINEER_EMAIL], msg.as_string())
        return True, "sent"
    except Exception as e:
        print(f"[agents] Email send failed: {e}")
        return False, str(e)


def evaluate_feeder(feeder_id, predicted_mw, confidence_mw, capacity_mw, all_predictions):
    """Runs the full Act pipeline for one feeder's prediction.
    Returns the recommendation record (dict) so the UI can show it."""
    overloaded = predicted_mw > capacity_mw

    if not overloaded:
        rec_id = db.log_recommendation(
            feeder_id, predicted_mw, confidence_mw, capacity_mw,
            overloaded=False, action="none",
        )
        return {"id": rec_id, "action": "none", "overloaded": False}

    # Overloaded -> rebalancing agent looks for spare capacity elsewhere
    target = db.get_spare_capacity(feeder_id, all_predictions)

    if target:
        rec_id = db.log_recommendation(
            feeder_id, predicted_mw, confidence_mw, capacity_mw,
            overloaded=True, action="rebalance", target_feeder=target,
        )
        return {
            "id": rec_id,
            "action": "rebalance",
            "overloaded": True,
            "target_feeder": target,
        }
    else:
        # Escalation agent -- no spare capacity anywhere, email an engineer
        sent, detail = send_escalation_email(feeder_id, predicted_mw, capacity_mw, confidence_mw)
        rec_id = db.log_recommendation(
            feeder_id, predicted_mw, confidence_mw, capacity_mw,
            overloaded=True, action="escalate",
        )
        return {
            "id": rec_id,
            "action": "escalate",
            "overloaded": True,
            "email_sent": sent,
            "email_detail": detail,
        }


def approve_and_execute(recommendation_id):
    """Called when a human clicks 'approve' in the UI. Logs a mock execution --
    this project never touches a real grid, it only proves the full
    predict -> recommend -> approve -> execute loop is real and traceable."""
    db.log_execution(recommendation_id, result="executed (simulated)")
    return {"recommendation_id": recommendation_id, "status": "executed"}
