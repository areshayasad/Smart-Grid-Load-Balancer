"""
Run:
    uvicorn serve:app --reload --port 8000
Then open http://localhost:8000/docs to try it.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from fastapi import FastAPI
from pydantic import BaseModel

from model import DemandLSTM
import db
import agents

ROOT = Path(__file__).resolve().parent.parent
MODELS_DIR = ROOT / "models"
DATA_PATH = ROOT / "data" / "raw" / "load_data.csv"

app = FastAPI(title="Smart grid load balancer")

# ---- load model + scaler once at startup ----
with open(MODELS_DIR / "scaler.json") as f:
    SCALER = json.load(f)
with open(MODELS_DIR / "metrics.json") as f:
    METRICS = json.load(f)

FEATURE_COLS = SCALER["feature_cols"]
WINDOW = SCALER["window"]

model = DemandLSTM(n_features=len(FEATURE_COLS))
model.load_state_dict(torch.load(MODELS_DIR / "best_model.pt", map_location="cpu"))
model.eval()

DF = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])

db.init_db()


class PredictRequest(BaseModel):
    feeder_id: str


def build_window_features(feeder_id):
    sub = DF[DF["feeder_id"] == feeder_id].sort_values("timestamp").tail(WINDOW).copy()
    sub["load_norm"] = (sub["load_mw"] - SCALER["load_mean"]) / SCALER["load_std"]
    sub["temp_norm"] = (sub["temperature_c"] - SCALER["temp_mean"]) / SCALER["temp_std"]
    sub["hour_frac"] = pd.to_datetime(sub["timestamp"]).dt.hour / 23.0
    feats = sub[FEATURE_COLS].to_numpy(dtype=np.float32)
    return torch.tensor(feats).unsqueeze(0), sub["capacity_mw"].iloc[-1]


def predict_feeder(feeder_id):
    x, capacity_mw = build_window_features(feeder_id)
    with torch.no_grad():
        pred_norm = model(x).item()
    predicted_mw = pred_norm * SCALER["load_std"] + SCALER["load_mean"]
    confidence_mw = METRICS["residual_std_mw"]
    return predicted_mw, confidence_mw, capacity_mw


@app.get("/")
def root():
    return {"status": "ok", "feeders": list(db.FEEDERS.keys())}


@app.post("/predict")
def predict(req: PredictRequest):
    predicted_mw, confidence_mw, capacity_mw = predict_feeder(req.feeder_id)
    return {
        "feeder_id": req.feeder_id,
        "predicted_mw": round(predicted_mw, 1),
        "confidence_mw": round(confidence_mw, 1),
        "capacity_mw": capacity_mw,
        "exceeds_capacity": predicted_mw > capacity_mw,
    }


@app.post("/act")
def act(req: PredictRequest):
    """Runs prediction + the full agent pipeline (rebalance or escalate)."""
    all_predictions = {}
    for fid in db.FEEDERS:
        p, _, _ = predict_feeder(fid)
        all_predictions[fid] = p

    predicted_mw, confidence_mw, capacity_mw = predict_feeder(req.feeder_id)
    result = agents.evaluate_feeder(
        req.feeder_id, predicted_mw, confidence_mw, capacity_mw, all_predictions
    )
    result["predicted_mw"] = round(predicted_mw, 1)
    result["confidence_mw"] = round(confidence_mw, 1)
    result["capacity_mw"] = capacity_mw
    return result


class ApproveRequest(BaseModel):
    recommendation_id: int


@app.post("/approve")
def approve(req: ApproveRequest):
    return agents.approve_and_execute(req.recommendation_id)
