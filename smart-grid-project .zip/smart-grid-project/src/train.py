"""
Trains the demand forecasting LSTM.

Run:
    python src/train.py

Reads:
    data/raw/load_data.csv
Writes:
    models/best_model.pt      (trained weights)
    models/scaler.json        (normalization stats, needed by serve.py)
    models/metrics.json       (best run's val metrics + residual std for CI)
    models/run_log.csv        (one row per training run -- the "log every run" step)
"""
import json
import csv
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from model import DemandLSTM

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "raw" / "load_data.csv"
MODELS_DIR = ROOT / "models"
MODELS_DIR.mkdir(exist_ok=True)

WINDOW = 24          # look back 24 hours to predict the next hour
FEEDERS = ["feeder_1", "feeder_2", "feeder_3", "feeder_4"]
FEATURE_COLS = ["load_norm", "temp_norm", "is_weekend", "is_special_day", "hour_frac"]


def build_features(df, load_mean, load_std, temp_mean, temp_std):
    df = df.copy()
    df["load_norm"] = (df["load_mw"] - load_mean) / load_std
    df["temp_norm"] = (df["temperature_c"] - temp_mean) / temp_std
    df["hour_frac"] = pd.to_datetime(df["timestamp"]).dt.hour / 23.0
    return df


class SequenceDataset(Dataset):
    def __init__(self, df, window=WINDOW):
        self.samples = []
        for feeder in FEEDERS:
            sub = df[df["feeder_id"] == feeder].sort_values("timestamp")
            feats = sub[FEATURE_COLS].to_numpy(dtype=np.float32)
            targets = sub["load_norm"].to_numpy(dtype=np.float32)
            for i in range(len(sub) - window):
                x = feats[i : i + window]
                y = targets[i + window]
                self.samples.append((x, y))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        x, y = self.samples[idx]
        return torch.tensor(x), torch.tensor(y)


def main(epochs=6, batch_size=128, lr=1e-3):
    print("Loading data...")
    df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])

    # chronological split (never split time series randomly)
    cutoff = df["timestamp"].quantile(0.85)
    train_df = df[df["timestamp"] < cutoff]
    val_df = df[df["timestamp"] >= cutoff]

    load_mean, load_std = train_df["load_mw"].mean(), train_df["load_mw"].std()
    temp_mean, temp_std = train_df["temperature_c"].mean(), train_df["temperature_c"].std()

    train_df = build_features(train_df, load_mean, load_std, temp_mean, temp_std)
    val_df = build_features(val_df, load_mean, load_std, temp_mean, temp_std)

    train_ds = SequenceDataset(train_df)
    val_ds = SequenceDataset(val_df)
    print(f"Train sequences: {len(train_ds):,} | Val sequences: {len(val_ds):,}")

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    model = DemandLSTM(n_features=len(FEATURE_COLS))
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    run_log_path = MODELS_DIR / "run_log.csv"
    is_new_log = not run_log_path.exists()
    log_file = open(run_log_path, "a", newline="")
    log_writer = csv.writer(log_file)
    if is_new_log:
        log_writer.writerow(["timestamp", "epoch", "train_loss", "val_loss"])

    best_val_loss = float("inf")
    best_residuals = None

    for epoch in range(1, epochs + 1):
        model.train()
        train_losses = []
        for x, y in train_loader:
            optimizer.zero_grad()
            pred = model(x)
            loss = loss_fn(pred, y)
            loss.backward()
            optimizer.step()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        residuals = []
        with torch.no_grad():
            for x, y in val_loader:
                pred = model(x)
                val_losses.append(loss_fn(pred, y).item())
                residuals.extend((pred - y).tolist())

        train_loss = float(np.mean(train_losses))
        val_loss = float(np.mean(val_losses))
        print(f"Epoch {epoch}/{epochs}  train_loss={train_loss:.4f}  val_loss={val_loss:.4f}")
        log_writer.writerow([datetime.now().isoformat(), epoch, train_loss, val_loss])
        log_file.flush()

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_residuals = residuals
            torch.save(model.state_dict(), MODELS_DIR / "best_model.pt")

    log_file.close()

    # residual std (in normalized space) -> used to build the confidence interval
    residual_std_norm = float(np.std(best_residuals))
    residual_std_mw = residual_std_norm * load_std

    scaler = {
        "load_mean": load_mean,
        "load_std": load_std,
        "temp_mean": temp_mean,
        "temp_std": temp_std,
        "window": WINDOW,
        "feature_cols": FEATURE_COLS,
    }
    with open(MODELS_DIR / "scaler.json", "w") as f:
        json.dump(scaler, f, indent=2)

    metrics = {
        "best_val_loss_norm": best_val_loss,
        "residual_std_mw": residual_std_mw,
        "trained_at": datetime.now().isoformat(),
        "epochs": epochs,
    }
    with open(MODELS_DIR / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nSaved best model -> {MODELS_DIR / 'best_model.pt'}")
    print(f"Residual std (68% confidence band width): {residual_std_mw:.1f} MW")


if __name__ == "__main__":
    main()
