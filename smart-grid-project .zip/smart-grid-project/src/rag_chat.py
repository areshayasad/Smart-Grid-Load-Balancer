"""
RAG chatbot. Embeddings run locally (free, no API key, no internet needed
after the model downloads once) using sentence-transformers. Only the final
answer generation calls a free LLM API (Groq).

Get a free Groq API key: https://console.groq.com/keys (no credit card needed)
Put it in .env as GROQ_API_KEY=...

Run standalone for a quick test:
    python src/rag_chat.py "why is feeder 4 close to its limit"
"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from groq import Groq

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
KB_DIR = ROOT / "knowledge_base"
CHROMA_DIR = ROOT / "chroma_store"

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"  # ~80MB, downloads once
GROQ_MODEL = "llama-3.1-8b-instant"

_embeddings = None
_vectorstore = None
_groq_client = None


def get_embeddings():
    global _embeddings
    if _embeddings is None:
        _embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    return _embeddings


def build_vectorstore():
    """Call once (or whenever knowledge_base/ changes) to (re)build the index."""
    docs = []
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    for path in KB_DIR.glob("*.txt"):
        loaded = TextLoader(str(path)).load()
        docs.extend(splitter.split_documents(loaded))

    vectorstore = Chroma.from_documents(
        docs, get_embeddings(), persist_directory=str(CHROMA_DIR)
    )
    print(f"Indexed {len(docs)} chunks from {KB_DIR} into {CHROMA_DIR}")
    return vectorstore


def get_vectorstore():
    global _vectorstore
    if _vectorstore is None:
        if not CHROMA_DIR.exists():
            _vectorstore = build_vectorstore()
        else:
            _vectorstore = Chroma(
                persist_directory=str(CHROMA_DIR), embedding_function=get_embeddings()
            )
    return _vectorstore


def get_groq_client():
    global _groq_client
    if _groq_client is None:
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise RuntimeError(
                "GROQ_API_KEY not set. Get a free key at "
                "https://console.groq.com/keys and add it to .env"
            )
        _groq_client = Groq(api_key=api_key)
    return _groq_client


def answer_question(question, live_prediction=None):
    """live_prediction: optional dict like
        {"feeder_id": "feeder_4", "predicted_mw": 210, "confidence_mw": 12, "capacity_mw": 220}
    so the chatbot can ground its answer in the model's actual current output,
    not just the static knowledge base."""
    vectorstore = get_vectorstore()
    hits = vectorstore.similarity_search(question, k=3)
    context = "\n\n".join(h.page_content for h in hits)

    live_context = ""
    if live_prediction:
        live_context = (
            f"\n\nLive model prediction for {live_prediction['feeder_id']}: "
            f"{live_prediction['predicted_mw']} MW "
            f"(+/- {live_prediction['confidence_mw']} MW) against a capacity of "
            f"{live_prediction['capacity_mw']} MW."
        )

    system_prompt = (
        "You are a grid operations assistant. Answer the question using only "
        "the context provided below. Be concise, plain-language, and specific. "
        "If the context doesn't contain the answer, say so honestly.\n\n"
        f"Context:\n{context}{live_context}"
    )

    client = get_groq_client()
    response = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        temperature=0.2,
        max_tokens=300,
    )
    return response.choices[0].message.content


if __name__ == "__main__":
    q = " ".join(sys.argv[1:]) or "Why does feeder 1 peak during Ramadan?"
    print(f"Q: {q}\n")
    print(answer_question(q))
