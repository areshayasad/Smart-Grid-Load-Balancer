"""SQLite is used instead of a real database server -- zero install, zero
extra disk beyond a small .db file, and it's enough to make the Act layer's
outputs real and checkable (a requirement your project needs to satisfy)."""
import sqlite3
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "grid.db"

FEEDERS = {
    "feeder_1": 300,
    "feeder_2": 260,
    "feeder_3": 340,
    "feeder_4": 220,
}


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """CREATE TABLE IF NOT EXISTS feeders (
            feeder_id TEXT PRIMARY KEY,
            capacity_mw REAL
        )"""
    )
    cur.execute(
        """CREATE TABLE IF NOT EXISTS recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT,
            feeder_id TEXT,
            predicted_mw REAL,
            confidence_mw REAL,
            capacity_mw REAL,
            overloaded INTEGER,
            action TEXT,
            target_feeder TEXT,
            status TEXT DEFAULT 'pending'
        )"""
    )
    cur.execute(
        """CREATE TABLE IF NOT EXISTS executions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recommendation_id INTEGER,
            executed_at TEXT,
            result TEXT
        )"""
    )
    for fid, cap in FEEDERS.items():
        cur.execute(
            "INSERT OR IGNORE INTO feeders (feeder_id, capacity_mw) VALUES (?, ?)",
            (fid, cap),
        )
    conn.commit()
    conn.close()


def log_recommendation(feeder_id, predicted_mw, confidence_mw, capacity_mw,
                        overloaded, action, target_feeder=None):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO recommendations
           (created_at, feeder_id, predicted_mw, confidence_mw, capacity_mw,
            overloaded, action, target_feeder)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            datetime.now().isoformat(),
            feeder_id,
            predicted_mw,
            confidence_mw,
            capacity_mw,
            int(overloaded),
            action,
            target_feeder,
        ),
    )
    conn.commit()
    rec_id = cur.lastrowid
    conn.close()
    return rec_id


def log_execution(recommendation_id, result):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO executions (recommendation_id, executed_at, result) VALUES (?, ?, ?)",
        (recommendation_id, datetime.now().isoformat(), result),
    )
    cur.execute(
        "UPDATE recommendations SET status = 'executed' WHERE id = ?",
        (recommendation_id,),
    )
    conn.commit()
    conn.close()


def get_spare_capacity(exclude_feeder, latest_predictions):
    """latest_predictions: dict {feeder_id: predicted_mw}. Returns a feeder_id
    with spare headroom, or None."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT feeder_id, capacity_mw FROM feeders WHERE feeder_id != ?", (exclude_feeder,))
    best = None
    best_headroom = 0
    for row in cur.fetchall():
        fid, cap = row["feeder_id"], row["capacity_mw"]
        pred = latest_predictions.get(fid, cap * 0.7)  # assume 70% load if unknown
        headroom = cap - pred
        if headroom > best_headroom:
            best_headroom = headroom
            best = fid
    conn.close()
    if best and best_headroom > 15:  # need a meaningful margin, not 1 MW
        return best
    return None


if __name__ == "__main__":
    init_db()
    print(f"Initialized database at {DB_PATH}")
