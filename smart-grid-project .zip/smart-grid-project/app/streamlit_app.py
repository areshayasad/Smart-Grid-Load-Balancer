"""
Run:
    streamlit run app/streamlit_app.py
"""
import sys
from pathlib import Path

import requests
import streamlit as st
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
import rag_chat  # noqa: E402

API_URL = "http://localhost:8000"
FEEDERS = ["feeder_1", "feeder_2", "feeder_3", "feeder_4"]

st.set_page_config(page_title="Smart grid load balancer", layout="centered")
st.title("Smart grid load balancer")
st.caption("Predict -> explain -> recommend -> escalate -> human approves -> execute")

feeder = st.selectbox("Feeder", FEEDERS)

col1, col2 = st.columns(2)

with col1:
    if st.button("Get prediction", use_container_width=True):
        try:
            resp = requests.post(f"{API_URL}/predict", json={"feeder_id": feeder}, timeout=10)
            st.session_state["prediction"] = resp.json()
        except requests.exceptions.ConnectionError:
            st.error("Can't reach the API. Run `uvicorn serve:app --port 8000` first "
                      "(see README step 4).")

with col2:
    if st.button("Run agent (Act layer)", use_container_width=True):
        try:
            resp = requests.post(f"{API_URL}/act", json={"feeder_id": feeder}, timeout=10)
            st.session_state["act_result"] = resp.json()
        except requests.exceptions.ConnectionError:
            st.error("Can't reach the API. Run `uvicorn serve:app --port 8000` first.")

if "prediction" in st.session_state:
    p = st.session_state["prediction"]
    st.subheader("Prediction")
    st.metric(
        label=f"{p['feeder_id']} predicted demand",
        value=f"{p['predicted_mw']} MW",
        delta=f"+/- {p['confidence_mw']} MW",
    )
    st.write(f"Capacity: {p['capacity_mw']} MW")
    if p["exceeds_capacity"]:
        st.warning("Predicted demand exceeds capacity.")
    else:
        st.success("Within capacity.")

if "act_result" in st.session_state:
    r = st.session_state["act_result"]
    st.subheader("Agent recommendation")
    st.json(r)

    if r.get("action") == "rebalance":
        st.info(f"Suggested: shift load to {r['target_feeder']}, which has spare capacity.")
    elif r.get("action") == "escalate":
        if r.get("email_sent"):
            st.warning("No spare capacity found anywhere -- escalation email sent to engineer.")
        else:
            st.warning(f"No spare capacity found. Email not sent ({r.get('email_detail')}). "
                       f"Set SMTP_USER / SMTP_PASSWORD in .env to enable real emails.")

    if r.get("action") in ("rebalance", "escalate"):
        if st.button("Approve and execute", use_container_width=True):
            approve_resp = requests.post(
                f"{API_URL}/approve", json={"recommendation_id": r["id"]}, timeout=10
            )
            st.success(f"Executed: {approve_resp.json()}")

st.divider()
st.subheader("Ask the chatbot")
question = st.text_input("e.g. Why is feeder_4 close to its limit today?")
if st.button("Ask") and question:
    live = st.session_state.get("prediction")
    with st.spinner("Thinking..."):
        try:
            answer = rag_chat.answer_question(question, live_prediction=live)
            st.write(answer)
        except RuntimeError as e:
            st.error(str(e))
