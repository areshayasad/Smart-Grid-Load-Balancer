# Smart grid load balancer

Predicts electricity demand per feeder, explains the prediction through a
chatbot, and has an agent recommend a fix (or escalate to a human) before
any load-shedding happens.

Pipeline: **Data -> Train -> Serve -> Chat -> Act**, matching the five-step
spine from your course brief.

---

## 0. What you need before starting

- Python 3.10 or 3.11 installed (check with `python3 --version`)
- About 2-3 GB of free disk space (mostly PyTorch + the embedding model —
  see the space-saving notes at the bottom if you're tight on room)
- A free [Groq](https://console.groq.com/keys) account for the chatbot's LLM
  (no credit card required, takes 1 minute)
- Optional: a Gmail account, if you want the escalation agent to send a
  real email (otherwise it just logs "no email sent" and the rest of the
  project still works)

---

## 1. Create and activate a virtual environment

A virtual environment keeps this project's packages separate from your
system Python, and makes it easy to delete everything later without
leftover clutter.

```bash
cd smart-grid-project

# create the venv
python3 -m venv venv

# activate it
# macOS / Linux:
source venv/bin/activate
# Windows (cmd):
venv\Scripts\activate.bat
# Windows (PowerShell):
venv\Scripts\Activate.ps1
```

Your terminal prompt should now start with `(venv)`. Every command below
assumes the venv is active.

---

## 2. Install dependencies

To save disk space, install the **CPU-only** build of PyTorch first (the
default PyPI version bundles CUDA/GPU support you don't need and it's
much larger):

```bash
pip install torch --index-url https://download.pytorch.org/whl/cpu

pip install -r requirements.txt
```

This installs everything: FastAPI, Streamlit, LangChain, Chroma,
sentence-transformers, and the Groq client. Total install size is
roughly 1.5-2 GB — mostly PyTorch and the embedding model that
sentence-transformers downloads on first use.

**If space is still too tight**, you can skip local embeddings and use a
smaller footprint by removing `sentence-transformers` and using Chroma's
built-in lightweight embedding function instead — let me know if you want
that swapped version.

---

## 3. Get the dataset

You have two options. Both produce the exact same file
(`data/raw/load_data.csv`) in the exact same format, so everything else
in the project (training, serving, the chatbot) works identically either
way — pick one.

### Option A — real dataset (recommended if your sir wants authentic data)

```bash
python data/download_real_data.py
```

This downloads **real hourly electricity demand for 4 actual US
utilities** — AEP, ComEd, Dayton Power & Light, and Duke Energy
Ohio/Kentucky — all part of the PJM Interconnection grid. It's the
well-known "Hourly Energy Consumption" dataset
(`kaggle.com/datasets/robikscube/hourly-energy-consumption`), pulled from
a public GitHub mirror so **no Kaggle account or login is needed**.

It also fetches **real historical hourly temperature** for each utility's
approximate service area from the free [Open-Meteo Archive
API](https://open-meteo.com/en/docs/historical-weather-api) (no API key
needed either). Each of the 4 utilities becomes one "feeder" in the
project:

| Feeder | Real utility | Region |
|---|---|---|
| feeder_1 | AEP Ohio | Columbus, OH |
| feeder_2 | ComEd | Chicago, IL |
| feeder_3 | Dayton Power & Light | Dayton, OH |
| feeder_4 | Duke Energy Ohio/Kentucky | Cincinnati, OH |

By default it keeps the most recent 2 years per feeder (enough to train
on, keeps the weather download quick). Change `YEARS_TO_KEEP` at the top
of the script if you want more history — up to 2004–2018 is available.

**One honest caveat to mention in your report:** real substation capacity
figures aren't public, so the script approximates each feeder's capacity
as its observed peak load × 1.15 (a 15% safety margin) — this is a
standard planning assumption, not the utility's real number. Everything
else (the load values, the weather) is real.

Takes 1-2 minutes depending on your connection (downloading ~4 CSVs plus
4 weather API calls).

### Option B — synthetic dataset (fastest, works fully offline)

```bash
python data/generate_data.py
```

Generates a realistic synthetic dataset (hourly demand for 4 feeders,
2 years, with weather and Ramadan effects baked in) — nothing to
download, runs in seconds, good for quickly testing the pipeline before
committing to the real download.

---

## 4. Set up your free API key

```bash
cp .env.example .env
```

Open `.env` in any text editor and paste in your Groq API key:

```
GROQ_API_KEY=gsk_your_key_here
```

(Leave the SMTP fields blank for now — you can add them later for the
real-email feature.)

---

## 5. Train the model

```bash
cd src
python train.py
```

This trains for 6 epochs (~1-2 minutes on a laptop CPU), prints train/val
loss each epoch, and saves:
- `models/best_model.pt` — the trained weights
- `models/scaler.json` — normalization stats (needed by the API)
- `models/metrics.json` — validation loss + the confidence interval width
- `models/run_log.csv` — one row per training run, your training log

---

## 6. Build the chatbot's knowledge base (one-time)

```bash
python rag_chat.py "test question"
```

The first run downloads the small embedding model (~80MB, one-time) and
builds the vector index from `knowledge_base/*.txt` into `chroma_store/`.
You should see a real answer printed from Groq. If you get a
`GROQ_API_KEY not set` error, double check step 4.

---

## 7. Start the API server

Keep this terminal running, and open a **new terminal** (remember to
`source venv/bin/activate` again in the new one) for the next step.

```bash
cd src
uvicorn serve:app --reload --port 8000
```

Visit `http://localhost:8000/docs` — you should see interactive API docs
and can try `/predict` right there.

---

## 8. Launch the demo UI

In your second terminal:

```bash
cd app
streamlit run streamlit_app.py
```

This opens a browser tab where you can:
1. Pick a feeder and click **Get prediction** (calls the Serve layer)
2. Click **Run agent (Act layer)** — this logs a recommendation, and
   either suggests rebalancing to a nearby feeder or sends a real
   escalation email if none has spare capacity
3. Click **Approve and execute** to complete the human-in-the-loop step
4. Type a question in the chat box, e.g. *"why is feeder_4 close to its
   limit today?"* — the chatbot answers using both the knowledge base
   and the live prediction

---

## 9. Where to find your "proof" artifacts for the demo

- **Training log:** `models/run_log.csv`
- **Recommendations table:** open `grid.db` with any SQLite browser
  (e.g. [DB Browser for SQLite](https://sqlitebrowser.org/), free), or run:
  ```bash
  python -c "import sqlite3; c=sqlite3.connect('grid.db'); print(c.execute('SELECT * FROM recommendations').fetchall())"
  ```
- **Sent email:** check the inbox you set as `ENGINEER_EMAIL`
- **Execution log:** same `grid.db`, table `executions`

---

## Project structure

```
smart-grid-project/
├── data/
│   ├── download_real_data.py  # step 3, option A (real data)
│   ├── generate_data.py        # step 3, option B (synthetic)
│   └── raw/load_data.csv       # generated by either script
├── src/
│   ├── model.py               # LSTM definition
│   ├── train.py                # step 5
│   ├── serve.py                 # step 7 (FastAPI)
│   ├── rag_chat.py               # step 6 (RAG chatbot)
│   ├── agents.py                  # Act layer logic
│   └── db.py                       # SQLite helpers
├── app/
│   └── streamlit_app.py            # step 8 (demo UI)
├── knowledge_base/                  # RAG source documents
├── models/                           # trained weights + metrics (generated)
├── requirements.txt
├── .env.example
└── README.md
```

---

## Troubleshooting

- **"Can't reach the API" in Streamlit** → make sure `uvicorn` from step 7
  is still running in its own terminal.
- **`GROQ_API_KEY not set`** → check `.env` has the key and you copied
  `.env.example` to `.env` (not just edited the example).
- **Email not sending** → Gmail requires an **App Password**, not your
  normal password, and requires 2-Step Verification to be turned on.
  Generate one at `myaccount.google.com/apppasswords`. If you skip this,
  the project still runs — it just logs "email not configured" instead
  of sending, which is fine for the demo.
- **Running low on disk** → after you're done, `deactivate` the venv and
  delete the whole `venv/` folder — it's fully self-contained and safe to
  remove without touching your system Python.
