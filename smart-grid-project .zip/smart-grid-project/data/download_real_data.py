"""
Downloads REAL hourly electricity demand data for 4 real US utility regions
(AEP, COMED, Dayton, DEOK -- all part of the PJM Interconnection grid), mirrored
on GitHub from the well-known Kaggle "Hourly Energy Consumption" dataset --
so no Kaggle account/login is needed:
  https://www.kaggle.com/datasets/robikscube/hourly-energy-consumption
  (mirror: https://github.com/panambY/Hourly_Energy_Consumption)

Also pulls REAL historical hourly temperature for each region's approximate
service area from the free Open-Meteo Archive API (no key needed):
  https://open-meteo.com/en/docs/historical-weather-api

Writes data/raw/load_data.csv in the exact same schema generate_data.py uses,
so nothing else in the project (train.py, serve.py) needs to change.

Run:
    python data/download_real_data.py
"""
import io
from pathlib import Path

import numpy as np
import pandas as pd
import requests

try:
    import holidays
except ImportError:
    holidays = None
    print("Note: 'holidays' package not installed -- is_special_day will be 0 "
          "for every row. Run: pip install holidays")

# Each entry: the real PJM region CSV (from the GitHub mirror above) mapped to
# a "feeder", plus the approximate lat/lon of that utility's service area
# (used only to fetch matching real weather).
REGIONS = {
    "feeder_1": {"file": "AEP_hourly.csv",    "col": "AEP_MW",    "lat": 39.96, "lon": -82.99},  # Columbus, OH (AEP Ohio)
    "feeder_2": {"file": "COMED_hourly.csv",  "col": "COMED_MW",  "lat": 41.88, "lon": -87.63},  # Chicago, IL (ComEd)
    "feeder_3": {"file": "DAYTON_hourly.csv", "col": "DAYTON_MW", "lat": 39.76, "lon": -84.19},  # Dayton, OH
    "feeder_4": {"file": "DEOK_hourly.csv",   "col": "DEOK_MW",   "lat": 39.10, "lon": -84.51},  # Cincinnati, OH (Duke Energy)
}

GITHUB_BASE = "https://raw.githubusercontent.com/panambY/Hourly_Energy_Consumption/master/data"

# Keep only the most recent N years per feeder -- plenty of data to train on,
# and keeps the weather download small and fast.
YEARS_TO_KEEP = 2


def download_load_csv(filename):
    url = f"{GITHUB_BASE}/{filename}"
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return pd.read_csv(io.StringIO(resp.text))


def fetch_weather(lat, lon, start_date, end_date):
    """Real historical hourly temperature, free, no API key."""
    url = "https://archive-api.open-meteo.com/v1/archive"
    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start_date,
        "end_date": end_date,
        "hourly": "temperature_2m",
        "timezone": "auto",
    }
    resp = requests.get(url, params=params, timeout=60)
    resp.raise_for_status()
    data = resp.json()["hourly"]
    weather = pd.DataFrame({
        "timestamp": pd.to_datetime(data["time"]),
        "temperature_c": data["temperature_2m"],
    })
    return weather


def main():
    us_holidays = holidays.US() if holidays else {}
    all_rows = []

    for feeder_id, cfg in REGIONS.items():
        print(f"Downloading {cfg['file']} for {feeder_id}...")
        raw = download_load_csv(cfg["file"])
        raw = raw.rename(columns={"Datetime": "timestamp", cfg["col"]: "load_mw"})
        raw["timestamp"] = pd.to_datetime(raw["timestamp"])
        raw = raw.sort_values("timestamp").drop_duplicates("timestamp")

        # keep only the most recent N years to keep things fast + manageable
        cutoff = raw["timestamp"].max() - pd.DateOffset(years=YEARS_TO_KEEP)
        raw = raw[raw["timestamp"] >= cutoff].reset_index(drop=True)

        start_date = raw["timestamp"].min().strftime("%Y-%m-%d")
        end_date = raw["timestamp"].max().strftime("%Y-%m-%d")
        print(f"  {len(raw):,} rows, {start_date} to {end_date} -- fetching real weather...")

        weather = fetch_weather(cfg["lat"], cfg["lon"], start_date, end_date)
        merged = pd.merge_asof(
            raw.sort_values("timestamp"),
            weather.sort_values("timestamp"),
            on="timestamp",
            direction="nearest",
        )

        merged["feeder_id"] = feeder_id
        merged["is_weekend"] = (merged["timestamp"].dt.weekday >= 5).astype(int)
        merged["is_special_day"] = merged["timestamp"].dt.date.apply(
            lambda d: int(d in us_holidays)
        )
        # Real capacity data isn't public -- approximate it as observed peak
        # load with a 15% safety margin, same assumption every grid planner
        # makes when exact substation capacity isn't published. State this
        # assumption explicitly in your report.
        merged["capacity_mw"] = round(merged["load_mw"].max() * 1.15, 1)

        all_rows.append(
            merged[["timestamp", "feeder_id", "load_mw", "temperature_c",
                    "is_weekend", "is_special_day", "capacity_mw"]]
        )

    df = pd.concat(all_rows, ignore_index=True)
    out_dir = Path(__file__).parent / "raw"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / "load_data.csv"
    df.to_csv(out_path, index=False)
    print(f"\nWrote {len(df):,} real rows to {out_path}")
    print("Feeders map to real utilities: feeder_1=AEP, feeder_2=ComEd, "
          "feeder_3=Dayton Power & Light, feeder_4=Duke Energy Ohio/Kentucky")


if __name__ == "__main__":
    main()
