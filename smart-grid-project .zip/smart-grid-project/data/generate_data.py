"""
Generates synthetic-but-realistic hourly electricity demand data for 4 feeders.
No account or download needed. If you'd rather use a real public dataset instead,
see the README section "Using a real dataset" for the PJM Kaggle dataset instructions.

Run:
    python data/generate_data.py
Output:
    data/raw/load_data.csv
"""
import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)

FEEDERS = {
    "feeder_1": {"base": 220, "capacity": 300},
    "feeder_2": {"base": 180, "capacity": 260},
    "feeder_3": {"base": 260, "capacity": 340},
    "feeder_4": {"base": 150, "capacity": 220},
}

START = "2023-01-01"
END = "2024-12-31"

# Rough "Ramadan-like" windows for 2023/2024 (used only to shift the demand
# curve for the demo -- not astronomically exact, that's fine for this project)
RAMADAN_WINDOWS = [
    ("2023-03-23", "2023-04-20"),
    ("2024-03-11", "2024-04-09"),
]


def is_ramadan(ts):
    for start, end in RAMADAN_WINDOWS:
        if pd.Timestamp(start) <= ts <= pd.Timestamp(end):
            return True
    return False


def synth_temperature(ts):
    day_of_year = ts.dayofyear
    seasonal = 22 + 14 * np.sin(2 * np.pi * (day_of_year - 80) / 365)
    daily = 6 * np.sin(2 * np.pi * (ts.hour - 6) / 24)
    noise = np.random.normal(0, 1.5)
    return round(seasonal + daily + noise, 1)


def demand_for_feeder(ts, temp, base, ramadan):
    hour = ts.hour
    weekday = ts.weekday()

    daily_shape = (
        1.0
        + 0.35 * np.exp(-((hour - 20) ** 2) / 8)   # evening peak
        + 0.15 * np.exp(-((hour - 9) ** 2) / 8)    # morning bump
    )

    weekend_factor = 0.92 if weekday >= 5 else 1.0
    temp_factor = 1.0 + max(0, (temp - 28)) * 0.02

    if ramadan:
        daily_shape += 0.4 * np.exp(-((hour - 19) ** 2) / 4)
        daily_shape += 0.25 * np.exp(-((hour - 4) ** 2) / 4)

    noise = np.random.normal(1.0, 0.05)
    load = base * daily_shape * weekend_factor * temp_factor * noise
    return max(0, round(load, 1))


def main():
    ts_range = pd.date_range(START, END, freq="h")
    rows = []
    for ts in ts_range:
        temp = synth_temperature(ts)
        ramadan = is_ramadan(ts)
        for feeder_id, cfg in FEEDERS.items():
            load = demand_for_feeder(ts, temp, cfg["base"], ramadan)
            rows.append(
                {
                    "timestamp": ts,
                    "feeder_id": feeder_id,
                    "load_mw": load,
                    "temperature_c": temp,
                    "is_weekend": int(ts.weekday() >= 5),
                    "is_special_day": int(ramadan),
                    "capacity_mw": cfg["capacity"],
                }
            )

    df = pd.DataFrame(rows)
    out_dir = Path(__file__).parent / "raw"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / "load_data.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df):,} rows to {out_path}")


if __name__ == "__main__":
    main()
